
# SAP Fiori tools - Environment Check

<br>

## Destination Details (1)

### Details for `MyCapDest`
🚫 &nbsp; OData V2 catalog service not available.<br>
🚫 &nbsp; OData V4 catalog service not available.<br>
✅ &nbsp; The destination property: `HTML5.DynamicDestination` is set to `true`.<br>
✅ &nbsp; The destination property `HTML5.Timeout` is set and must include a minimum value of `60000`.<br>
✅ &nbsp; SAP Fiori tools usage: Configured to be used by SAP Fiori Generator as a partial URL.<br>
|Name|Description|Host|sap-client|Fiori tools usage|WebIDEUsage|WebIDEAdditionalData|Type|Authentication|ProxyType|HTML5.DynamicDestination|HTML5.Timeout|
|--|--|--|--|--|--|--|--|--|--|--|--|
|MyCapDest|A secure connect to my cap service so fiori Team can use my cap application data|https://e5a1a4b2trial-dev-mycapapp-srv.cfapps.us10-001.hana.ondemand.com||Partial URL|odata_gen||HTTP|OAuth2UserTokenExchange|Internet|true|60000|

<br>

## Messages (19)
🟢 &nbsp; Info: Platform: linux<br>
🟢 &nbsp; Info: Development environment: Business Application Studio<br>
🟢 &nbsp; Info: Business Application Studio dev space: Full Stack Cloud Application.<br>
🟢 &nbsp; Info: Cloud CLI tools: 8.7.4<br>
🟢 &nbsp; Info: Application Wizard: 1.20.2<br>
🟢 &nbsp; Info: SAP Fiori tools - SAP Fiori generator: 1.22.0.<br>
🟢 &nbsp; Info: SAP Fiori tools - Application Modeler: 1.22.0<br>
🟢 &nbsp; Info: SAP Fiori tools - Guided Development: 1.22.0<br>
🟢 &nbsp; Info: SAP Fiori tools - Service Modeler: 1.22.0<br>
🟢 &nbsp; Info: SAP Fiori tools - XML Annotation Language Server: 1.22.0<br>
🟢 &nbsp; Info: XML Toolkit: 1.2.1<br>
🟢 &nbsp; Info: SAP CDS Language Support: 9.6.3.<br>
🟢 &nbsp; Info: UI5 Language Assistant Support: 4.0.94<br>
🟢 &nbsp; Info: Versions: {
    "node": "22.13.1",
    "acorn": "8.14.0",
    "ada": "2.9.2",
    "amaro": "0.2.0",
    "ares": "1.34.4",
    "brotli": "1.1.0",
    "cjs_module_lexer": "1.4.1",
    "cldr": "46.0",
    "icu": "76.1",
    "llhttp": "9.2.1",
    "modules": "127",
    "napi": "9",
    "nbytes": "0.1.1",
    "ncrypto": "0.0.1",
    "nghttp2": "1.64.0",
    "nghttp3": "1.6.0",
    "ngtcp2": "1.9.1",
    "openssl": "3.0.15+quic",
    "simdjson": "3.10.1",
    "simdutf": "5.6.4",
    "sqlite": "3.47.2",
    "tz": "2024b",
    "undici": "6.21.1",
    "unicode": "16.0",
    "uv": "1.49.2",
    "uvwasi": "0.0.21",
    "v8": "12.4.254.21-node.22",
    "zlib": "1.3.0.1-motley-82a5fec"
}.<br>
🟢 &nbsp; Info: Found 1 destinations.<br>
🔴 &nbsp; Error: Cannot query v2 catalog service for MyCapDest.<br>
<details><summary>ℹ Debug</summary>
<pre>
 Request to URL:  failed with message: e.catalog is not a function. Complete error object: {}
</pre></details>
🔴 &nbsp; Error: Cannot query v4 catalog service for MyCapDest.<br>
<details><summary>ℹ Debug</summary>
<pre>
 Request to URL:  failed with message: e.catalog is not a function. Complete error object: {}
</pre></details>

<br>

## All Destinations (1)
<details>
<summary>Show all destinations.</summary>

|Name|Description|Host|sap-client|Fiori tools usage|WebIDEUsage|WebIDEAdditionalData|Type|Authentication|ProxyType|HTML5.DynamicDestination|HTML5.Timeout|
|--|--|--|--|--|--|--|--|--|--|--|--|
|MyCapDest|A secure connect to my cap service so fiori Team can use my cap application data|https://e5a1a4b2trial-dev-mycapapp-srv.cfapps.us10-001.hana.ondemand.com||Partial URL|odata_gen||HTTP|OAuth2UserTokenExchange|Internet|true|60000|

</details>

<br>

## Environment
Platform: `linux`<br>
Development environment: `Business Application Studio`<br>
Dev Space Type: `Full Stack Cloud Application`<br>
|Tools/Extensions|Version|
|--|--|
|Node.js|22.13.1|
|Cloud CLI tools|8.7.4|
|SAP Fiori tools - Fiori generator|1.22.0|
|Application Wizard|1.20.2|
|SAP Fiori tools - Application Modeler|1.22.0|
|SAP Fiori tools - Guided Development|1.22.0|
|SAP Fiori tools - Service Modeler|1.22.0|
|SAP Fiori tools - XML Annotation Language Server|1.22.0|
|XML Toolkit|1.2.1|
|SAP CDS Language Support|9.6.3|
|UI5 Language Assistant Support|4.0.94|
<details><summary>Versions</summary>
<pre>
{
    "node": "22.13.1",
    "acorn": "8.14.0",
    "ada": "2.9.2",
    "amaro": "0.2.0",
    "ares": "1.34.4",
    "brotli": "1.1.0",
    "cjs_module_lexer": "1.4.1",
    "cldr": "46.0",
    "icu": "76.1",
    "llhttp": "9.2.1",
    "modules": "127",
    "napi": "9",
    "nbytes": "0.1.1",
    "ncrypto": "0.0.1",
    "nghttp2": "1.64.0",
    "nghttp3": "1.6.0",
    "ngtcp2": "1.9.1",
    "openssl": "3.0.15+quic",
    "simdjson": "3.10.1",
    "simdutf": "5.6.4",
    "sqlite": "3.47.2",
    "tz": "2024b",
    "undici": "6.21.1",
    "unicode": "16.0",
    "uv": "1.49.2",
    "uvwasi": "0.0.21",
    "v8": "12.4.254.21-node.22",
    "zlib": "1.3.0.1-motley-82a5fec"
}
</pre></details>

<sub>created at 2026-04-02 09:54:06 (UTC)</sub>
